# Trin Backend API

This folder contains the serverless functions for Trin's diagnosis engine.